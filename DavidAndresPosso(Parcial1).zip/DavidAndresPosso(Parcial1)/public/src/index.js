import * as components from "./components/index.js"
import data from "./data.js"

class ListContainer extends HTMLElement{

    constructor(){
        super();
        this.attachShadow({mode:"open"})
    }

    connectedCallback(){
        this.render();
    }
    
    render(){
        data.forEach((PJ) => {
            this.shadowRoot.innerHTML += `
            <section>
            <h1>${PJ.name}</h1> <button>See alternative name(s)</button> <p>Specie: ${PJ.species}</p> <p>Gender: ${PJ.gender}</p> <p>House: ${PJ.house}</p> <p>Born Year: ${PJ.yearOfBirth}</p>
            </section>
            `
        });
    }
}

customElements.define("my-list",ListContainer)