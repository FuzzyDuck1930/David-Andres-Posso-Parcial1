class button extends HTMLElement{

    constructor(){
        super();
        this.attachShadow({mode:"open"})
    }

    connectedCallback(){
        this.mount
    }

    static get observedAttributes(){
        return["name","alter"]
    }

    attributeChangedCallback(propName,oldValue,newValue){
        this[propName] = newValue;
    }

    mount(){
        this.render();
        this.addListener(); 
    }

    addListener(){
        this.shadowRoot.querySelector("button").addEventListener("click",this.onButtonClicked)
    }

    render(){
        this.shadowRoot.innerHTML = `
        <h1 class="nome">${this.name}</h1>
        <h1 class="alt">${this.alter}</h1>
        `
    }

    onButtonClicked(){
        currentValue = this.getAttribute("name")

        currentValue === "nome" ? this.setAttribute("name","nome") : this.setAttribute("name","alt")
    }
}

customElements.define("my-button",button);
export default button