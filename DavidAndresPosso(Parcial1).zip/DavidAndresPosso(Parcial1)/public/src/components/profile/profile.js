class profile extends HTMLElement{

    constructor(){
        super();
        this.attachShadow({mode:"open"})
    }

    connectedCallback(){
        this.render();
    }

    static get observedAttributes(){
        return["specie","gender","house","yearB"]
    }

    attributeChangedCallback(propName,oldValue,newValue){
        this[propName] = newValue;
    }

    render(){
        this.shadowRoot.innerHTML = `
        <p>${this.specie}</p>
        <p>${this.gender}</p>
        <p>${this.house}</p>
        <p>${this.yearB}</p>
        `
    }
}

customElements.define("my-profile",profile)
export default profile